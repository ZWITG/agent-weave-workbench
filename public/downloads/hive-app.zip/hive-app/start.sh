#!/usr/bin/env bash
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Please install Node.js 20+ from https://nodejs.org"; exit 1; }
[ -d node_modules ] || npm install
(sleep 6; (xdg-open http://localhost:8080 || open http://localhost:8080) >/dev/null 2>&1) &
npm run dev -- --port 8080
