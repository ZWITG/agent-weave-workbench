@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Please install Node.js 20+ from https://nodejs.org & pause & exit /b 1)
if not exist node_modules call npm install
start "" cmd /c "timeout /t 6 >nul & start http://localhost:8080"
npm run dev -- --port 8080
